﻿namespace AddQuotationMarks
{
    partial class Main
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this.InputBox = new System.Windows.Forms.TextBox();
            this.OutBox = new System.Windows.Forms.TextBox();
            this.ADD = new System.Windows.Forms.Button();
            this.CLEAN = new System.Windows.Forms.Button();
            this.AD_ZERO = new System.Windows.Forms.Button();
            this.COPY = new System.Windows.Forms.Button();
            this.TO_UPEER = new System.Windows.Forms.Button();
            this.WAIT = new System.Windows.Forms.Button();
            this.IntextBox = new System.Windows.Forms.TextBox();
            this.加MAC = new System.Windows.Forms.Label();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.Label_Message_Text = new System.Windows.Forms.Label();
            this.Panel_BOX = new System.Windows.Forms.Panel();
            this.UrTextBox = new System.Windows.Forms.TextBox();
            this.CaptChas = new System.Windows.Forms.PictureBox();
            this.PicEmpBox = new System.Windows.Forms.PictureBox();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.btnAppend = new System.Windows.Forms.ToolStripButton();
            this.btnModify = new System.Windows.Forms.ToolStripButton();
            this.uploadBTN = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.btnExport = new System.Windows.Forms.ToolStripButton();
            this.firstBTN = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.everyPageNumCKB = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.goBTN = new System.Windows.Forms.Button();
            this.editPageNum = new System.Windows.Forms.TextBox();
            this.lastPageBTN = new System.Windows.Forms.Button();
            this.nextPageLabe = new System.Windows.Forms.Button();
            this.prePageBTN = new System.Windows.Forms.Button();
            this.pageNumLabel = new System.Windows.Forms.Label();
            this.gvData = new System.Windows.Forms.DataGridView();
            this.editFilter = new System.Windows.Forms.TextBox();
            this.combFilter = new System.Windows.Forms.ComboBox();
            this.Checked_Discarded = new System.Windows.Forms.CheckBox();
            this.CheckYesNo = new System.Windows.Forms.TextBox();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.ProgressBarTxt = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.Panel_BOX.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CaptChas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicEmpBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvData)).BeginInit();
            this.SuspendLayout();
            // 
            // InputBox
            // 
            this.InputBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.InputBox.Location = new System.Drawing.Point(23, 82);
            this.InputBox.Multiline = true;
            this.InputBox.Name = "InputBox";
            this.InputBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.InputBox.Size = new System.Drawing.Size(306, 398);
            this.InputBox.TabIndex = 0;
            // 
            // OutBox
            // 
            this.OutBox.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.OutBox.Location = new System.Drawing.Point(363, 82);
            this.OutBox.Multiline = true;
            this.OutBox.Name = "OutBox";
            this.OutBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.OutBox.Size = new System.Drawing.Size(306, 398);
            this.OutBox.TabIndex = 1;
            // 
            // ADD
            // 
            this.ADD.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ADD.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.ADD.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ADD.Location = new System.Drawing.Point(23, 486);
            this.ADD.Name = "ADD";
            this.ADD.Size = new System.Drawing.Size(74, 32);
            this.ADD.TabIndex = 2;
            this.ADD.Text = "ADD";
            this.ADD.UseVisualStyleBackColor = false;
            this.ADD.Click += new System.EventHandler(this.ADD_Click);
            // 
            // CLEAN
            // 
            this.CLEAN.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CLEAN.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.CLEAN.Location = new System.Drawing.Point(140, 486);
            this.CLEAN.Name = "CLEAN";
            this.CLEAN.Size = new System.Drawing.Size(74, 32);
            this.CLEAN.TabIndex = 3;
            this.CLEAN.Text = "CLEAN";
            this.CLEAN.UseVisualStyleBackColor = false;
            this.CLEAN.Click += new System.EventHandler(this.CLEAN_Click);
            // 
            // AD_ZERO
            // 
            this.AD_ZERO.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.AD_ZERO.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AD_ZERO.Location = new System.Drawing.Point(255, 486);
            this.AD_ZERO.Name = "AD_ZERO";
            this.AD_ZERO.Size = new System.Drawing.Size(74, 32);
            this.AD_ZERO.TabIndex = 4;
            this.AD_ZERO.Text = "AD_ZERO";
            this.AD_ZERO.UseVisualStyleBackColor = false;
            this.AD_ZERO.Click += new System.EventHandler(this.AD_ZERO_Click);
            // 
            // COPY
            // 
            this.COPY.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.COPY.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.COPY.Location = new System.Drawing.Point(479, 486);
            this.COPY.Name = "COPY";
            this.COPY.Size = new System.Drawing.Size(74, 32);
            this.COPY.TabIndex = 5;
            this.COPY.Text = "COPY";
            this.COPY.UseVisualStyleBackColor = false;
            this.COPY.Click += new System.EventHandler(this.COPY_Click);
            // 
            // TO_UPEER
            // 
            this.TO_UPEER.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.TO_UPEER.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TO_UPEER.Location = new System.Drawing.Point(363, 486);
            this.TO_UPEER.Name = "TO_UPEER";
            this.TO_UPEER.Size = new System.Drawing.Size(74, 32);
            this.TO_UPEER.TabIndex = 6;
            this.TO_UPEER.Text = "TO_UPPER";
            this.TO_UPEER.UseVisualStyleBackColor = false;
            this.TO_UPEER.Click += new System.EventHandler(this.TO_UPEER_Click);
            // 
            // WAIT
            // 
            this.WAIT.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.WAIT.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.WAIT.Location = new System.Drawing.Point(595, 486);
            this.WAIT.Name = "WAIT";
            this.WAIT.Size = new System.Drawing.Size(74, 32);
            this.WAIT.TabIndex = 7;
            this.WAIT.Text = "WAIT";
            this.WAIT.UseVisualStyleBackColor = false;
            this.WAIT.Click += new System.EventHandler(this.WAIT_Click);
            // 
            // IntextBox
            // 
            this.IntextBox.Location = new System.Drawing.Point(255, 524);
            this.IntextBox.Name = "IntextBox";
            this.IntextBox.Size = new System.Drawing.Size(74, 21);
            this.IntextBox.TabIndex = 8;
            // 
            // 加MAC
            // 
            this.加MAC.AutoSize = true;
            this.加MAC.BackColor = System.Drawing.Color.Transparent;
            this.加MAC.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.加MAC.ForeColor = System.Drawing.Color.Yellow;
            this.加MAC.Location = new System.Drawing.Point(363, 531);
            this.加MAC.Name = "加MAC";
            this.加MAC.Size = new System.Drawing.Size(196, 14);
            this.加MAC.TabIndex = 9;
            this.加MAC.Text = "加MAC可辅助使用TO_UPPER！！";
            // 
            // PictureBox1
            // 
            this.PictureBox1.Location = new System.Drawing.Point(667, 82);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(317, 306);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox1.TabIndex = 11;
            this.PictureBox1.TabStop = false;
            // 
            // Label_Message_Text
            // 
            this.Label_Message_Text.BackColor = System.Drawing.SystemColors.Control;
            this.Label_Message_Text.Cursor = System.Windows.Forms.Cursors.Default;
            this.Label_Message_Text.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Label_Message_Text.Font = new System.Drawing.Font("宋体", 18F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Label_Message_Text.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.Label_Message_Text.Location = new System.Drawing.Point(0, 0);
            this.Label_Message_Text.Name = "Label_Message_Text";
            this.Label_Message_Text.Size = new System.Drawing.Size(1499, 64);
            this.Label_Message_Text.TabIndex = 0;
            this.Label_Message_Text.Text = "Message";
            this.Label_Message_Text.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Panel_BOX
            // 
            this.Panel_BOX.Controls.Add(this.Label_Message_Text);
            this.Panel_BOX.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Panel_BOX.Location = new System.Drawing.Point(0, 639);
            this.Panel_BOX.Name = "Panel_BOX";
            this.Panel_BOX.Size = new System.Drawing.Size(1499, 64);
            this.Panel_BOX.TabIndex = 10;
            // 
            // UrTextBox
            // 
            this.UrTextBox.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.UrTextBox.Location = new System.Drawing.Point(675, 404);
            this.UrTextBox.Name = "UrTextBox";
            this.UrTextBox.Size = new System.Drawing.Size(137, 29);
            this.UrTextBox.TabIndex = 12;
            this.UrTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.UrTextBox_KeyPress);
            // 
            // CaptChas
            // 
            this.CaptChas.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.CaptChas.Location = new System.Drawing.Point(796, 194);
            this.CaptChas.Name = "CaptChas";
            this.CaptChas.Size = new System.Drawing.Size(109, 29);
            this.CaptChas.TabIndex = 13;
            this.CaptChas.TabStop = false;
            this.CaptChas.Visible = false;
            this.CaptChas.Click += new System.EventHandler(this.CaptChas_Click);
            // 
            // PicEmpBox
            // 
            this.PicEmpBox.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PicEmpBox.Location = new System.Drawing.Point(840, 404);
            this.PicEmpBox.Name = "PicEmpBox";
            this.PicEmpBox.Size = new System.Drawing.Size(136, 29);
            this.PicEmpBox.TabIndex = 14;
            this.PicEmpBox.TabStop = false;
            this.PicEmpBox.Click += new System.EventHandler(this.PicEmpBox_Click);
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.CountItem = null;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.btnAppend,
            this.btnModify,
            this.uploadBTN,
            this.bindingNavigatorSeparator2,
            this.btnExport});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = null;
            this.bindingNavigator1.Size = new System.Drawing.Size(1499, 40);
            this.bindingNavigator1.TabIndex = 15;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorAddNewItem.Text = "新添";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorMoveFirstItem.Text = "移到第一条记录";
            this.bindingNavigatorMoveFirstItem.Visible = false;
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorMovePreviousItem.Text = "移到上一条记录";
            this.bindingNavigatorMovePreviousItem.Visible = false;
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 40);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "位置";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "当前位置";
            this.bindingNavigatorPositionItem.Visible = false;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(32, 37);
            this.bindingNavigatorCountItem.Text = "/ {0}";
            this.bindingNavigatorCountItem.ToolTipText = "总项数";
            this.bindingNavigatorCountItem.Visible = false;
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 40);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorMoveNextItem.Text = "移到下一条记录";
            this.bindingNavigatorMoveNextItem.Visible = false;
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorMoveLastItem.Text = "移到最后一条记录";
            this.bindingNavigatorMoveLastItem.Visible = false;
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 37);
            this.bindingNavigatorDeleteItem.Text = "删除";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // btnAppend
            // 
            this.btnAppend.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAppend.Image = global::AddQuotationMarks.Properties.Resources.gif_47_080;
            this.btnAppend.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnAppend.Name = "btnAppend";
            this.btnAppend.Size = new System.Drawing.Size(36, 37);
            this.btnAppend.Text = "新增";
            this.btnAppend.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // btnModify
            // 
            this.btnModify.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnModify.Image = global::AddQuotationMarks.Properties.Resources.gif_47_040;
            this.btnModify.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(36, 37);
            this.btnModify.Text = "修改";
            this.btnModify.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // uploadBTN
            // 
            this.uploadBTN.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.uploadBTN.Image = global::AddQuotationMarks.Properties.Resources.gif_47_065;
            this.uploadBTN.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.uploadBTN.Name = "uploadBTN";
            this.uploadBTN.Size = new System.Drawing.Size(36, 37);
            this.uploadBTN.Text = "导入";
            this.uploadBTN.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.uploadBTN.Click += new System.EventHandler(this.uploadBTN_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 40);
            // 
            // btnExport
            // 
            this.btnExport.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnExport.Image = global::AddQuotationMarks.Properties.Resources.gif_47_042;
            this.btnExport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnExport.Name = "btnExport";
            this.btnExport.Size = new System.Drawing.Size(36, 37);
            this.btnExport.Text = "导出";
            this.btnExport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            // 
            // firstBTN
            // 
            this.firstBTN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.firstBTN.Location = new System.Drawing.Point(371, 8);
            this.firstBTN.Name = "firstBTN";
            this.firstBTN.Size = new System.Drawing.Size(66, 23);
            this.firstBTN.TabIndex = 16;
            this.firstBTN.Text = "首页";
            this.firstBTN.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(935, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 12);
            this.label3.TabIndex = 25;
            this.label3.Text = "条";
            // 
            // everyPageNumCKB
            // 
            this.everyPageNumCKB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.everyPageNumCKB.FormattingEnabled = true;
            this.everyPageNumCKB.Items.AddRange(new object[] {
            "50",
            "100",
            "150",
            "200",
            "250",
            "500"});
            this.everyPageNumCKB.Location = new System.Drawing.Point(854, 11);
            this.everyPageNumCKB.Name = "everyPageNumCKB";
            this.everyPageNumCKB.Size = new System.Drawing.Size(76, 20);
            this.everyPageNumCKB.TabIndex = 24;
            this.everyPageNumCKB.SelectedValueChanged += new System.EventHandler(this.everyPageNumCKB_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(818, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 23;
            this.label2.Text = "每页";
            // 
            // goBTN
            // 
            this.goBTN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.goBTN.Location = new System.Drawing.Point(782, 8);
            this.goBTN.Name = "goBTN";
            this.goBTN.Size = new System.Drawing.Size(29, 23);
            this.goBTN.TabIndex = 22;
            this.goBTN.Text = "GO";
            this.goBTN.UseVisualStyleBackColor = true;
            // 
            // editPageNum
            // 
            this.editPageNum.Location = new System.Drawing.Point(676, 8);
            this.editPageNum.Name = "editPageNum";
            this.editPageNum.Size = new System.Drawing.Size(100, 21);
            this.editPageNum.TabIndex = 21;
            // 
            // lastPageBTN
            // 
            this.lastPageBTN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lastPageBTN.Location = new System.Drawing.Point(587, 8);
            this.lastPageBTN.Name = "lastPageBTN";
            this.lastPageBTN.Size = new System.Drawing.Size(75, 23);
            this.lastPageBTN.TabIndex = 20;
            this.lastPageBTN.Text = "末页";
            this.lastPageBTN.UseVisualStyleBackColor = true;
            // 
            // nextPageLabe
            // 
            this.nextPageLabe.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.nextPageLabe.Location = new System.Drawing.Point(515, 8);
            this.nextPageLabe.Name = "nextPageLabe";
            this.nextPageLabe.Size = new System.Drawing.Size(66, 23);
            this.nextPageLabe.TabIndex = 19;
            this.nextPageLabe.Text = "下一页";
            this.nextPageLabe.UseVisualStyleBackColor = true;
            // 
            // prePageBTN
            // 
            this.prePageBTN.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.prePageBTN.Location = new System.Drawing.Point(443, 8);
            this.prePageBTN.Name = "prePageBTN";
            this.prePageBTN.Size = new System.Drawing.Size(66, 23);
            this.prePageBTN.TabIndex = 18;
            this.prePageBTN.Text = "上一页";
            this.prePageBTN.UseVisualStyleBackColor = true;
            // 
            // pageNumLabel
            // 
            this.pageNumLabel.AutoSize = true;
            this.pageNumLabel.Location = new System.Drawing.Point(974, 16);
            this.pageNumLabel.Name = "pageNumLabel";
            this.pageNumLabel.Size = new System.Drawing.Size(167, 12);
            this.pageNumLabel.TabIndex = 17;
            this.pageNumLabel.Text = "共0条记录  共0页  当前第0页";
            // 
            // gvData
            // 
            this.gvData.AllowUserToAddRows = false;
            this.gvData.AllowUserToDeleteRows = false;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.Lavender;
            this.gvData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle10;
            this.gvData.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gvData.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.gvData.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.gvData.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.gvData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.gvData.DefaultCellStyle = dataGridViewCellStyle12;
            this.gvData.Location = new System.Drawing.Point(982, 82);
            this.gvData.MultiSelect = false;
            this.gvData.Name = "gvData";
            this.gvData.ReadOnly = true;
            this.gvData.RowHeadersWidth = 25;
            this.gvData.RowTemplate.Height = 24;
            this.gvData.Size = new System.Drawing.Size(517, 554);
            this.gvData.TabIndex = 26;
            this.gvData.VirtualMode = true;
            // 
            // editFilter
            // 
            this.editFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.editFilter.Location = new System.Drawing.Point(1316, 9);
            this.editFilter.Name = "editFilter";
            this.editFilter.Size = new System.Drawing.Size(137, 22);
            this.editFilter.TabIndex = 28;
            // 
            // combFilter
            // 
            this.combFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combFilter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.combFilter.FormattingEnabled = true;
            this.combFilter.Location = new System.Drawing.Point(1170, 8);
            this.combFilter.Name = "combFilter";
            this.combFilter.Size = new System.Drawing.Size(140, 24);
            this.combFilter.TabIndex = 27;
            // 
            // Checked_Discarded
            // 
            this.Checked_Discarded.AutoSize = true;
            this.Checked_Discarded.BackColor = System.Drawing.Color.Transparent;
            this.Checked_Discarded.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Checked_Discarded.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Checked_Discarded.Location = new System.Drawing.Point(596, 522);
            this.Checked_Discarded.Name = "Checked_Discarded";
            this.Checked_Discarded.Size = new System.Drawing.Size(72, 16);
            this.Checked_Discarded.TabIndex = 29;
            this.Checked_Discarded.Text = "是否报废";
            this.Checked_Discarded.UseVisualStyleBackColor = false;
            // 
            // CheckYesNo
            // 
            this.CheckYesNo.Location = new System.Drawing.Point(595, 544);
            this.CheckYesNo.Multiline = true;
            this.CheckYesNo.Name = "CheckYesNo";
            this.CheckYesNo.Size = new System.Drawing.Size(73, 24);
            this.CheckYesNo.TabIndex = 30;
            this.CheckYesNo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CheckYesNo_KeyPress);
            // 
            // ProgressBar
            // 
            this.ProgressBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.ProgressBar.Location = new System.Drawing.Point(0, 40);
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(1499, 23);
            this.ProgressBar.TabIndex = 31;
            // 
            // timer1
            // 
            this.timer1.Interval = 10;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // ProgressBarTxt
            // 
            this.ProgressBarTxt.AutoSize = true;
            this.ProgressBarTxt.Location = new System.Drawing.Point(173, 16);
            this.ProgressBarTxt.Name = "ProgressBarTxt";
            this.ProgressBarTxt.Size = new System.Drawing.Size(65, 12);
            this.ProgressBarTxt.TabIndex = 33;
            this.ProgressBarTxt.Text = "加载总进度";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(982, 438);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(516, 197);
            this.textBox1.TabIndex = 34;
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::AddQuotationMarks.Properties.Resources.ju1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1499, 703);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ProgressBarTxt);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.CheckYesNo);
            this.Controls.Add(this.Checked_Discarded);
            this.Controls.Add(this.editFilter);
            this.Controls.Add(this.combFilter);
            this.Controls.Add(this.gvData);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.everyPageNumCKB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.goBTN);
            this.Controls.Add(this.editPageNum);
            this.Controls.Add(this.lastPageBTN);
            this.Controls.Add(this.nextPageLabe);
            this.Controls.Add(this.prePageBTN);
            this.Controls.Add(this.pageNumLabel);
            this.Controls.Add(this.firstBTN);
            this.Controls.Add(this.bindingNavigator1);
            this.Controls.Add(this.PictureBox1);
            this.Controls.Add(this.PicEmpBox);
            this.Controls.Add(this.CaptChas);
            this.Controls.Add(this.UrTextBox);
            this.Controls.Add(this.Panel_BOX);
            this.Controls.Add(this.加MAC);
            this.Controls.Add(this.IntextBox);
            this.Controls.Add(this.WAIT);
            this.Controls.Add(this.TO_UPEER);
            this.Controls.Add(this.COPY);
            this.Controls.Add(this.AD_ZERO);
            this.Controls.Add(this.CLEAN);
            this.Controls.Add(this.ADD);
            this.Controls.Add(this.OutBox);
            this.Controls.Add(this.InputBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Main";
            this.Text = "AddQuotationMarks";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.Panel_BOX.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CaptChas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PicEmpBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gvData)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox InputBox;
        private System.Windows.Forms.TextBox OutBox;
        private System.Windows.Forms.Button ADD;
        private System.Windows.Forms.Button CLEAN;
        private System.Windows.Forms.Button AD_ZERO;
        private System.Windows.Forms.Button COPY;
        private System.Windows.Forms.Button TO_UPEER;
        private System.Windows.Forms.Button WAIT;
        private System.Windows.Forms.TextBox IntextBox;
        private System.Windows.Forms.Label 加MAC;
        private System.Windows.Forms.PictureBox PictureBox1;
        private System.Windows.Forms.Label Label_Message_Text;
        private System.Windows.Forms.Panel Panel_BOX;
        private System.Windows.Forms.TextBox UrTextBox;
        private System.Windows.Forms.PictureBox CaptChas;
        private System.Windows.Forms.PictureBox PicEmpBox;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton btnExport;
        private System.Windows.Forms.ToolStripButton btnAppend;
        private System.Windows.Forms.ToolStripButton btnModify;
        private System.Windows.Forms.ToolStripButton uploadBTN;
        private System.Windows.Forms.Button firstBTN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox everyPageNumCKB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button goBTN;
        private System.Windows.Forms.TextBox editPageNum;
        private System.Windows.Forms.Button lastPageBTN;
        private System.Windows.Forms.Button nextPageLabe;
        private System.Windows.Forms.Button prePageBTN;
        private System.Windows.Forms.Label pageNumLabel;
        private System.Windows.Forms.DataGridView gvData;
        private System.Windows.Forms.TextBox editFilter;
        private System.Windows.Forms.ComboBox combFilter;
        private System.Windows.Forms.CheckBox Checked_Discarded;
        private System.Windows.Forms.TextBox CheckYesNo;
        private System.Windows.Forms.ProgressBar ProgressBar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label ProgressBarTxt;
        private System.Windows.Forms.TextBox textBox1;
    }
}

